import os
import numpy as np
import torch
import cv2
from PIL import Image, ImageOps
from supernet_flattransf_3_8_8_8_13_12_0_16_60 import TransNetV2Supernet
from utils import get_batches, get_frames, scenes2zero_one_representation, predictions_to_scenes
from tqdm import tqdm

def predict_scene(batch):
    """Predict scenes for a batch of frames."""
    batch = torch.from_numpy(batch.transpose((3, 0, 1, 2))[np.newaxis, ...]).float()
    batch = batch.to(device)
    with torch.no_grad():
        one_hot = supernet_best_f1(batch)
    if isinstance(one_hot, tuple):
        one_hot = one_hot[0]
    return torch.sigmoid(one_hot[0]).cpu().numpy()

    

# Configuration
pretrained_path = "/kaggle/input/autoshot/other/default/1/ckpt_0_200_0.pth"
output_dir = '/kaggle/working/predicted_frames/'
os.makedirs(output_dir, exist_ok=True)

# Load TransNetV2Supernet model
supernet_best_f1 = TransNetV2Supernet().eval()

# Determine device
device = "cuda" if torch.cuda.is_available() else "cpu"

# Load pretrained weights
if os.path.exists(pretrained_path):
    print(f'Loading pretrained weights from {pretrained_path}')
    model_dict = supernet_best_f1.state_dict()
    pretrained_dict = torch.load(pretrained_path, map_location=device)
    pretrained_dict = {k: v for k, v in pretrained_dict['net'].items() if k in model_dict}
    print(f"Current model has {len(model_dict)} parameters, updated parameters {len(pretrained_dict)}")
    model_dict.update(pretrained_dict)
    supernet_best_f1.load_state_dict(model_dict)
else:
    raise Exception("Error: Cannot find pretrained best model!!")

# Move model to the appropriate device
if device == "cuda":
    supernet_best_f1 = supernet_best_f1.cuda()

# Define paths
video_dir = "/kaggle/input/aic2023"
fnm_path_dict = {}
for fnm in os.listdir(video_dir):
    if fnm.endswith(".mp4"):
        fnm_path_dict[fnm[:-len(".mp4")]] = os.path.join(video_dir, fnm)

# Original and target frame sizes
original_size = (48, 27)  # Size of the extracted frames

# Process each video
for i, (fnm, video_path) in enumerate(fnm_path_dict.items(), 1):
    print(f"Processing video {i}: {fnm}")
    folder_name = video_path.split('/')[-1].replace( '.mp4','')

    # test_folder = int(folder_name.replace('L05_V',''))
    # print(test_folder)
    # if test_folder <= 244 or test_folder==253 or test_folder==271:
    #     print(f"Skip {folder_name}")
    #     continue

    folder_path = output_dir + f'{folder_name}'
    os.makedirs(folder_path,exist_ok=True )
    # Extract frames with original resolution
    frames = get_frames(video_path, *original_size)

    total_frames = len(frames)
    if total_frames == 0:
        continue

    # Predict scene changes
    predictions = []
    for batch in get_batches(frames):
        pred = predict_scene(batch)
        predictions.append(pred)
    predictions = np.concatenate(predictions, axis=0)


    scene_boundaries = np.where(np.diff(predictions[:, 0] > 0.5))[0] + 1
    scenes = [0] + list(scene_boundaries) + [total_frames - 1]
    cam = cv2.VideoCapture(video_path)

    currentframe = 0
    index = 0

    while True:
        ret,frame = cam.read()
        if ret:
            currentframe += 1
            # for sc in scenes:
            if (index>len(scenes)-1):
              break
            idx_first, idx_end = scenes[index], scenes[index + 1]
            idx_025 = int(idx_first + (idx_end - idx_first) / 4)
            idx_05 = int(idx_first + (idx_end - idx_first) / 2)
            idx_075 = int(idx_first + 3 * (idx_end - idx_first) / 4)

            #### First ####
            if currentframe - 1 == idx_first:
                filename_first = "{}/{:0>6d}.jpg".format(folder_path, idx_first)
                # video_save = cv2.resize(video[idx_first], (1280,720))
                cv2.imwrite(filename_first, frame)

            # #### End ####
            if currentframe - 1 == idx_end:
                filename_end = "{}/{:0>6d}.jpg".format(folder_path, idx_end)
                # video_save = cv2.resize(video[idx_end], (1280,720))
                cv2.imwrite(filename_end, frame)
                index += 1

            # #### 05 ####
            if currentframe - 1 == idx_05:
                filename_05 = "{}/{:0>6d}.jpg".format(folder_path, idx_05)
                # video_save = cv2.resize(video[idx_05], (1280,720))
                cv2.imwrite(filename_05, frame)


        else:
            break

    cam.release()

print("Frame predictions saved.")

