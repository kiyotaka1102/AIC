import os
import numpy as np
import torch
from PIL import Image
from supernet_flattransf_3_8_8_8_13_12_0_16_60 import TransNetV2Supernet
from utils import get_frames, get_batches

def predict_scene(batch):
    """Predict scenes for a batch of frames."""
    batch = torch.from_numpy(batch.transpose((3, 0, 1, 2))[np.newaxis, ...]).float()
    batch = batch.to(device)
    with torch.no_grad():
        one_hot = supernet_best_f1(batch)
    if isinstance(one_hot, tuple):
        one_hot = one_hot[0]
    return torch.sigmoid(one_hot[0]).cpu().numpy()

def save_frame(frame, output_path, size=(1280, 720)):
    """Save a frame as an image with optional resizing."""
    # Resize frame
    img = Image.fromarray(frame)
    img = img.resize(size, Image.LANCZOS)
    img.save(output_path)

# Configuration
pretrained_path = "/content/drive/MyDrive/AIC24/model/ckpt_0_200_0.pth"
output_dir = '/content/predicted_frames/'
os.makedirs(output_dir, exist_ok=True)

# Load TransNetV2Supernet model
supernet_best_f1 = TransNetV2Supernet().eval()

# Determine device
device = "cuda" if torch.cuda.is_available() else "cpu"

# Load pretrained weights
if os.path.exists(pretrained_path):
    print(f'Loading pretrained weights from {pretrained_path}')
    model_dict = supernet_best_f1.state_dict()
    pretrained_dict = torch.load(pretrained_path, map_location=device)
    pretrained_dict = {k: v for k, v in pretrained_dict['net'].items() if k in model_dict}
    print(f"Current model has {len(model_dict)} parameters, updated parameters {len(pretrained_dict)}")
    model_dict.update(pretrained_dict)
    supernet_best_f1.load_state_dict(model_dict)
else:
    raise Exception("Error: Cannot find pretrained best model!!")

# Move model to the appropriate device
if device == "cuda":
    supernet_best_f1 = supernet_best_f1.cuda()

# Define paths
video_dir = "/content/video_download"
fnm_path_dict = {}
for fnm in os.listdir(video_dir):
    if fnm.endswith(".mp4"):
        fnm_path_dict[fnm[:-len(".mp4")]] = os.path.join(video_dir, fnm)

# Desired size for output frames
frame_size = (1280, 720)  # Change this to your desired size

# Process each video
for i, (fnm, video_path) in enumerate(fnm_path_dict.items(), 1):
    print(f"Processing video {i}: {fnm}")
    
    frames = get_frames(video_path)
    total_frames = len(frames)
    if total_frames == 0:
        continue

    # Predict scene changes
    predictions = []
    for batch in get_batches(frames):
        pred = predict_scene(batch)
        predictions.append(pred)
    predictions = np.concatenate(predictions, axis=0)
    
    # Find scene boundaries based on prediction
    scene_boundaries = np.where(np.diff(predictions[:, 0] > 0.5))[0] + 1
    scene_boundaries = [0] + list(scene_boundaries) + [total_frames - 1]

    # Process each scene
    for start_idx in range(len(scene_boundaries) - 1):
        start_frame = scene_boundaries[start_idx]
        end_frame = scene_boundaries[start_idx + 1]
        scene_frames = frames[start_frame:end_frame + 1]
        
        if len(scene_frames) == 0:
            continue

        # Define frame indices (start, middle, end) within the scene
        scene_length = len(scene_frames)
        indices = [0, scene_length // 2, scene_length - 1]

        for idx in indices:
            frame_idx = start_frame + idx
            if frame_idx >= total_frames:
                continue
            frame_image = frames[frame_idx]
            
            # Define output path with only 5-digit zero-padded frame number
            frame_number = str(frame_idx).zfill(5)
            frame_filename = f"frame_{frame_number}.png"
            frame_image_path = os.path.join(output_dir, frame_filename)
            
            # Save the frame image with resizing
            save_frame(frame_image, frame_image_path, size=frame_size)

print("Frame predictions saved.")
